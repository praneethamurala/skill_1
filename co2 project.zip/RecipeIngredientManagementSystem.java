import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RecipeIngredientManagementSystem {
    private Map<String, Recipe> recipeMap;

    public RecipeIngredientManagementSystem() {
        recipeMap = new HashMap<>(); // HashMap to store recipes
    }

    // Add a new recipe
    public void addRecipe(String recipeName) {
        recipeMap.put(recipeName, new Recipe(recipeName));
    }

    // Add an ingredient to a specific recipe
    public void addIngredientToRecipe(String recipeName, String ingredient) {
        Recipe recipe = recipeMap.get(recipeName);
        if (recipe != null) {
            recipe.addIngredient(ingredient);
            System.out.println(ingredient + " added to " + recipeName);
        } else {
            System.out.println("Recipe not found!");
        }
    }

    // Remove an ingredient from a specific recipe
    public void removeIngredientFromRecipe(String recipeName, String ingredient) {
        Recipe recipe = recipeMap.get(recipeName);
        if (recipe != null) {
            recipe.removeIngredient(ingredient);
            System.out.println(ingredient + " removed from " + recipeName);
        } else {
            System.out.println("Recipe not found!");
        }
    }

    // Display all ingredients of a recipe
    public void displayRecipe(String recipeName) {
        Recipe recipe = recipeMap.get(recipeName);
        if (recipe != null) {
            System.out.println(recipe);
        } else {
            System.out.println("Recipe not found!");
        }
    }

    // Search for recipes that contain a particular ingredient
    public void searchRecipesByIngredient(String ingredient) {
        System.out.println("Recipes with " + ingredient + ":");
        for (Recipe recipe : recipeMap.values()) {
            if (recipe.hasIngredient(ingredient)) {
                System.out.println(recipe);
            }
        }
    }

    public static void main(String[] args) {
        RecipeIngredientManagementSystem system = new RecipeIngredientManagementSystem();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Recipe Management System ---");
            System.out.println("1. Add a new recipe");
            System.out.println("2. Add ingredient to a recipe");
            System.out.println("3. Remove ingredient from a recipe");
            System.out.println("4. Display recipe");
            System.out.println("5. Search recipes by ingredient");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter recipe name: ");
                    String recipeName = scanner.nextLine();
                    system.addRecipe(recipeName);
                    break;
                case 2:
                    System.out.print("Enter recipe name: ");
                    recipeName = scanner.nextLine();
                    System.out.print("Enter ingredient to add: ");
                    String ingredient = scanner.nextLine();
                    system.addIngredientToRecipe(recipeName, ingredient);
                    break;
                case 3:
                    System.out.print("Enter recipe name: ");
                    recipeName = scanner.nextLine();
                    System.out.print("Enter ingredient to remove: ");
                    ingredient = scanner.nextLine();
                    system.removeIngredientFromRecipe(recipeName, ingredient);
                    break;
                case 4:
                    System.out.print("Enter recipe name: ");
                    recipeName = scanner.nextLine();
                    system.displayRecipe(recipeName);
                    break;
                case 5:
                    System.out.print("Enter ingredient to search: ");
                    ingredient = scanner.nextLine();
                    system.searchRecipesByIngredient(ingredient);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 6);

        scanner.close();
    }
}
