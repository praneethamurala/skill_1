import java.util.HashSet;
import java.util.Set;

public class Recipe {
    private String name;
    private Set<String> ingredients;

    public Recipe(String name) {
        this.name = name;
        this.ingredients = new HashSet<>(); // HashSet for unique ingredients
    }

    // Add ingredient to the recipe
    public void addIngredient(String ingredient) {
        ingredients.add(ingredient);
    }

    // Remove ingredient from the recipe
    public void removeIngredient(String ingredient) {
        ingredients.remove(ingredient);
    }

    // Check if the recipe contains a specific ingredient
    public boolean hasIngredient(String ingredient) {
        return ingredients.contains(ingredient);
    }

    // Get all ingredients
    public Set<String> getIngredients() {
        return ingredients;
    }

    @Override
    public String toString() {
        return "Recipe: " + name + ", Ingredients: " + ingredients;
    }
}
