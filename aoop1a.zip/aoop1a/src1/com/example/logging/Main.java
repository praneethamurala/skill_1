package com.example.logging;

public class Main {
	public static void main(String[] args) {
        Logger logger = Logger.getInstance();

        logger.log("Application started.");
        logger.log("Performing some operations...");
        logger.log("Application finished.");
        Logger anotherLogger = Logger.getInstance();
        anotherLogger.log("This message comes from another logger reference.");

        System.out.println("Logging completed. Check the log.txt file for log entries.");
    }
}
