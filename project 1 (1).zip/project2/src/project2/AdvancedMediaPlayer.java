package project2;

public interface AdvancedMediaPlayer {
	void playMp4(String fileName);
    void playVlc(String fileName);
}


